#!/usr/bin/env python
# -*- coding:utf-8 -*-
import scrapy
# 导入CrawlSpider类和Rule
from scrapy.spiders import CrawlSpider, Rule
# 导入链接规则匹配类，用来提取符合规则的连接
from scrapy.linkextractors import LinkExtractor
from baidu.items import BaiduItem

class BaiduSpider(scrapy.Spider):
    name = "baidu1"
    allow_domains =["talent.baidu.com"]
    start_urls = ["https://talent.baidu.com/external/baidu/index.html"]

    #pagelink = LinkExtractor(allow=("start=\d+"))

    #rules = [
        # 获取这个列表里的链接，依次发送请求，并且继续跟进，调用指定回调函数处理
       # Rule(pagelink, callback="parseTencent", follow=True)


def parse(self,response):
    for each in response.xpath("//div[@class='list-row']"):
        item = BaiduItem()
        item['positionname'] = each.xpath("./column1/a/@target/text()").extract()[0]
        item['positionlink'] = each.xpath("./column1/a/@href").extract()[0]
        item['positionType'] = each.xpath("./column2/text()").extract()[0]
        item['workLocation'] = each.xpath("./column3/text()").extract()[0]
        item['peopleNum'] = each.xpath("./column4/text()").extract()[0]
        item['publishTime'] = each.xpath("./column5/text()").extract()[0]

        yield item

    #yield scrapy.Request(start_urls, callback=parse)





